# 马哥小红书粉丝助手 · 0.3.1参考源码

Chrome Manifest V3扩展：作者旁手动查看粉丝数，右下角一键查看当前已加载前20条。默认不自动查询，插件没有小时或每日次数额度。

完整行为协议、跨系统步骤、消息协议、文件附录和实站验收见随附《小红书粉丝助手：跨环境一比一复刻文档》。此源码包与该文档的文件附录一致，SOURCE-MANIFEST.json记录每个源文件的SHA256。

## 使用

在目标Chrome资料中打开`chrome://extensions`，启用开发者模式，加载本项目的`extension`目录，再刷新已登录的小红书页面。无需API Key、Node.js、Python或服务器即可使用扩展。

## 开发验证

Node.js22+、Python3.9+；运行依赖安装、48项测试和打包：

```bash
npm ci --ignore-scripts
npm test
python scripts/package.py
```

Windows可使用`npm.cmd`和`py -3`，macOS/Linux通常使用`python3`。7个运行JS还应执行`node --check`。运行时无第三方依赖；jsdom仅供开发测试。

请勿为了取消次数额度删除3秒串行间隔或网站验证暂停。平台粉丝取整值保持其显示含义；平台自身的限制不能由插件取消。当前真实浏览器证据来自Windows，其他系统需在使用者电脑重新验收。
