const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
const A = '619e0b66000000001000e923';
const B = '64abc123000000000100abcd';
async function until(fn) {
  const end = Date.now() + 1500;
  while (!fn()) { if (Date.now() > end) throw Error('未收到主页数据'); await new Promise(r => setTimeout(r, 5)); }
}
function fixture(state = {}) {
  const dom = new JSDOM('', { url: `https://www.xiaohongshu.com/user/profile/${A}`, runScripts: 'outside-only' });
  const w = dom.window, messages = [];
  w.__INITIAL_STATE__ = state;
  w.addEventListener('message', e => { if (e.data?.type === 'profile') messages.push(e.data.profile); });
  return { dom, w, messages, load() {
    for (const file of ['core.js', 'page-bridge.js']) w.eval(fs.readFileSync(path.join(__dirname, '../extension', file), 'utf8'));
  } };
}
test('页面桥从当前主页状态读取真实 fans，保留 0', async () => {
  const f = fixture({ user: { userPageData: { _value: { basicInfo: { nickname: '示例' },
    interactions: [{ type: 'follows', count: '99' }, { type: 'fans', count: '0' }] } } } });
  try {
    f.load(); await until(() => f.messages.length > 0);
    assert.equal(f.messages[0].id, A); assert.equal(f.messages[0].value, 0);
  } finally { f.w.close(); }
});
test('fetch 桥克隆正常响应，不消耗小红书自己使用的正文', async () => {
  const f = fixture();
  const response = new Response(JSON.stringify({ success: true, data: { interacts: [{ type: 'fans', count: '1.2万' }] } }),
    { headers: { 'content-type': 'application/json' } });
  f.w.fetch = async () => response;
  try {
    f.load();
    assert.equal(await f.w.fetch(`https://edith.xiaohongshu.com/api/sns/web/v1/user/otherinfo?target_user_id=${A}`), response);
    await until(() => f.messages.length > 0);
    assert.equal(response.bodyUsed, false);
    assert.equal(f.messages[0].text, '1.2万'); assert.equal(f.messages[0].approximate, true);
  } finally { f.w.close(); }
});

test('SPA 离开初始主页再返回时，不把其他账号的遗留状态绑定给原账号', async () => {
  const f = fixture();
  try {
    f.load();
    f.w.history.pushState({}, '', `/user/profile/${B}`);
    f.w.__INITIAL_STATE__ = { user: { userPageData: { interactions: [{ type: 'fans', count: '999' }] } } };
    f.w.history.pushState({}, '', `/user/profile/${A}`);
    f.w.dispatchEvent(new f.w.MessageEvent('message', { source: f.w, origin: 'https://www.xiaohongshu.com',
      data: { channel: 'mage-xhs-fans-v1', type: 'ready' } }));
    const marker = new Promise(resolve => f.w.addEventListener('message', event => { if (event.data?.testMarker) resolve(); }));
    f.w.postMessage({ testMarker: true }, 'https://www.xiaohongshu.com'); await marker;
    assert.equal(f.messages.length, 0);
  } finally { f.w.close(); }
});
