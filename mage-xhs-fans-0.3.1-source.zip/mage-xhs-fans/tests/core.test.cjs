const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../extension/core.js');
const A = '619e0b66000000001000e923';
const B = '64abc123000000000100abcd';

test('粉丝数字：0、整数、千分位和平台取整值', () => {
  for (const [input, want] of [[0, { value: 0, text: '0', approximate: false }],
    ['12,345', { value: 12345, text: '12,345', approximate: false }],
    ['1.2万', { value: 12000, text: '1.2万', approximate: true }],
    ['2亿+', { value: 200000000, text: '2亿+', approximate: true }]]) {
    assert.deepEqual(C.normalizeCount(input), want);
  }
  for (const input of [null, undefined, '', -1, NaN, Infinity, '未知', '1.2', {}, true, '123粉丝', '1e6'])
    assert.equal(C.normalizeCount(input), null);
});

test('仅允许本站真实主页路径，保留现有安全参数，去除无关参数', () => {
  const p = C.profileUrl(`/user/profile/${A}?xsec_token=sample-test-token&xsec_source=pc_note&tracking=bad#tail`);
  assert.equal(p.id, A);
  assert.equal(p.url, `https://www.xiaohongshu.com/user/profile/${A}?xsec_token=sample-test-token&xsec_source=pc_note`);
  for (const url of [`https://evil.test/user/profile/${A}`, `http://www.xiaohongshu.com/user/profile/${A}`,
    `https://www.xiaohongshu.com.evil.test/user/profile/${A}`, '/user/profile/no-id',
    `https://a:b@www.xiaohongshu.com/user/profile/${A}`, `/user/profile/${A}/extra`])
    assert.equal(C.profileUrl(url), null);
});

test('主页直接结构及 Vue ref：只读粉丝，不读取关注或获赞', () => {
  const value = { basicInfo: { nickname: '教学示例' }, interactions: [
    { type: 'follows', name: '关注', count: '999' },
    { type: 'fans', name: '粉丝', count: '0' },
    { type: 'interaction', name: '获赞与收藏', count: '9999' }
  ] };
  for (const wrapped of [value, { value }, { _value: value }, { _rawValue: value }]) {
    assert.deepEqual(C.fromState({ user: { userPageData: wrapped } }, A),
      { id: A, value: 0, text: '0', approximate: false });
  }
  assert.equal(C.fromState({ user: { userPageData: { interactions: [{ type: 'follows', count: '4' }] } } }, A), null);
});

test('响应绑定请求中的 target_user_id，拒绝账号冲突及不相关响应', () => {
  const payload = { success: true, data: { basic_info: { nickname: '示例' },
    interacts: [{ type: 'fans', name: '粉丝', count: '1.2万' }] } };
  assert.equal(C.fromResponse(payload, `https://edith.xiaohongshu.com/api/sns/web/v1/user/otherinfo?target_user_id=${A}`).id, A);
  assert.equal(C.fromResponse(payload, `https://evil.test/api/sns/web/v1/user/otherinfo?target_user_id=${A}`), null);
  assert.equal(C.fromResponse(payload, 'https://edith.xiaohongshu.com/api/sns/web/v1/homefeed'), null);
  payload.data.basic_info.user_id = B;
  assert.equal(C.fromResponse(payload, `https://edith.xiaohongshu.com/api/sns/web/v1/user/otherinfo?target_user_id=${A}`), null);
  assert.equal(C.fromProfile({ userId: B, interactions: [{ type: 'fans', count: '2' }] }, A), null);
});

test('缓存记录只接受新鲜、合法并且身份相符的粉丝数字', () => {
  const now = 2_000_000;
  const record = { id: A, value: 0, text: '0', approximate: false, at: now - 10 };
  assert.equal(C.freshRecord(record, A, now).value, 0);
  assert.equal(C.freshRecord({ ...record, at: now - 1_800_001 }, A, now), null);
  assert.equal(C.freshRecord({ ...record, at: now + 10_000 }, A, now), null);
  assert.equal(C.freshRecord(record, B, now), null);
  assert.equal(C.freshRecord({ ...record, text: '<img onerror=alert(1)>' }, A, now), null);
});
