const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const A = '619e0b66000000001000e923';
const ROOT = path.join(__dirname, '../extension');
function fixture(initial) {
  let handler;
  const tabs = new Map(), removed = [], storage = {}, session = {};
  if (initial) storage.xhsFansState = initial;
  const api = {
    runtime: { id: 'extension-test', getURL: name => `chrome-extension://extension-test/${name}`,
      onMessage: { addListener: fn => { handler = fn; } } },
    storage: {
      local: { get: async key => ({ [key]: storage[key] }), set: async data => Object.assign(storage, data) },
      session: { get: async key => ({ [key]: session[key] }), set: async data => Object.assign(session, data) }
    },
    tabs: { create: async args => { const tab = { id: 77, url: args.url, active: false }; tabs.set(77, tab); return tab; },
      get: async id => { if (!tabs.has(id)) throw Error('closed'); return tabs.get(id); },
      remove: async id => { removed.push(id); tabs.delete(id); }, onRemoved: { addListener() {} }, onActivated: { addListener() {} } }
  };
  const context = vm.createContext({ chrome: api, URL, Date, Promise, setTimeout, clearTimeout, console });
  context.importScripts = (...files) => files.forEach(file => vm.runInContext(fs.readFileSync(path.join(ROOT, file), 'utf8'), context));
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), context);
  const content = (id = A, tabId = 5) => ({ id: api.runtime.id, frameId: 0,
    url: `https://www.xiaohongshu.com/user/profile/${id}`, tab: { id: tabId } });
  const popup = { id: api.runtime.id, url: api.runtime.getURL('popup.html') };
  return { tabs, removed, storage, content, popup,
    message: (msg, sender) => new Promise(resolve => handler(msg, sender, resolve)) };
}
test('后台拒绝外站、子框架和内容脚本修改设置', async () => {
  const f = fixture();
  assert.equal((await f.message({ type: 'INIT' }, { ...f.content(), url: 'https://evil.test/' })).status, 'forbidden');
  assert.equal((await f.message({ type: 'INIT' }, { ...f.content(), frameId: 1 })).status, 'forbidden');
  assert.equal((await f.message({ type: 'SET_OPTIONS', options: { enabled: false } }, f.content())).status, 'forbidden');
  assert.equal((await f.message({ type: 'SET_OPTIONS', options: { enabled: false } }, f.popup)).options.enabled, false);
});
test('从主页观察到的 0 粉丝进入缓存，错误绑定不进入缓存', async () => {
  const f = fixture();
  assert.equal((await f.message({ type: 'OBSERVE', profile: { id: A, value: 0, text: '0', approximate: false } }, f.content())).status, 'ok');
  const result = await f.message({ type: 'LOOKUP', url: `/user/profile/${A}`, manual: true }, f.content());
  assert.equal(result.profile.value, 0); assert.equal(f.tabs.size, 0);
  assert.equal((await f.message({ type: 'OBSERVE', profile: { id: '64abc123000000000100abcd', value: 1, text: '1', approximate: false } }, f.content())).status, 'invalid');
});
test('队列、临时页、主页采集和关闭标签页完成一次端到端消息流程', async () => {
  const f = fixture();
  const pending = f.message({ type: 'LOOKUP', url: `/user/profile/${A}`, manual: true }, f.content());
  for (let i = 0; i < 20 && !f.tabs.has(77); i++) await new Promise(r => setImmediate(r));
  assert.equal((await f.message({ type: 'INIT' }, f.content(A, 77))).probe, true);
  await f.message({ type: 'OBSERVE', profile: { id: A, value: 42, text: '42', approximate: false } }, f.content(A, 77));
  assert.equal((await pending).profile.value, 42);
  assert.deepEqual(f.removed, [77]);
});

test('升级移除旧额度并关闭旧自动设置，旧内容脚本不能偷偷读取主页', async () => {
  const f = fixture({ options: { enabled: true, automatic: true }, budget: { start: Date.now(), used: 60 } });
  const state = await f.message({ type: 'GET_STATE' }, f.popup);
  assert.equal(state.options.automatic, false);
  assert.equal(f.storage.xhsFansState.options.automatic, false);
  assert.equal(state.hourlyLimit, null);
  assert.equal(Object.hasOwn(f.storage.xhsFansState, 'budget'), false);
  const result = await f.message({ type: 'LOOKUP', url: `/user/profile/${A}` }, f.content());
  assert.equal(result.status, 'manual');
  assert.equal(f.tabs.size, 0);
  const legacy = await f.message({ type: 'SET_OPTIONS', options: { automatic: true } }, f.popup);
  assert.equal(legacy.options.automatic, false);
});
