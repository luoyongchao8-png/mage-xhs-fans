(() => {
  'use strict';
  if (location.origin !== 'https://www.xiaohongshu.com' || window !== window.top) return;
  const C = globalThis.XhsFans, CHANNEL = 'mage-xhs-fans-v1';
  const bindings = new Map(), cache = new Map();
  const OWN_UI = '.mage-xhs-fans, .mage-xhs-fans-tools';
  const firstPath = location.pathname;
  let enabled = false, probe = false, ready = false, scheduled = false, stopped = false;
  let domObserver, profileTimer, expiryTimer;
  let domProfileAllowed = true;
  let pauseReason = '', captured = '', haveProfile = false, failureSent = false;
  let tools, batchButton, batchStatus, batchCancel, batchRun = null, batchNote = '';
  const statusText = { paused: '查询暂停', login: '需登录', blocked: '需验证', 'rate-limited': '稍后查询',
    'queue-full': '队列已满·稍后重试', unavailable: '未获取·重试', timeout: '读取超时·重试',
    cancelled: '点击查看粉丝数', manual: '点击查看粉丝数', disabled: '点击查看粉丝数', invalid: '未获取' };

  async function send(message) {
    try { return await chrome.runtime.sendMessage(message); }
    catch { return { status: 'unavailable' }; }
  }
  function record(id) { return C.freshRecord(cache.get(id), id, Date.now()); }
  function paint(b) {
    if (stopped || !enabled || !b.link.isConnected || !b.badge.isConnected) return;
    const item = b.revealed ? record(b.id) : null;
    b.badge.dataset.state = item ? 'known' : b.pending ? 'loading' : b.status || 'unknown';
    const text = item ? `粉丝 ${item.text}` : b.pending ? '查询中…' : statusText[b.status] || '点击查看粉丝数';
    if (b.badge.textContent !== text) b.badge.textContent = text;
    b.badge.setAttribute('aria-label', item ? `${b.name}，${text}` : `查询${b.name}的粉丝数`);
    b.badge.disabled = b.pending;
    b.badge.setAttribute('aria-busy', String(b.pending));
    b.badge.title = item
      ? `小红书账号主页${item.approximate ? '显示值（有取整）' : '粉丝数'}；${new Date(item.at).toLocaleTimeString()} 读取，缓存 30 分钟。`
      : b.status === 'paused' ? '请打开插件，查看暂停原因；完成登录或验证后再继续。'
      : '点击才查看粉丝数，优先使用本地缓存；缺少缓存时短暂打开一个后台作者主页。浏览或滚动不会查询。';
  }
  function lookup(b) {
    if (stopped || !enabled || probe) return Promise.resolve({ status: 'cancelled' });
    if (b.pending) return b.inFlight || Promise.resolve({ status: 'cancelled' });
    b.revealed = true;
    const cached = record(b.id);
    if (cached) { b.status = ''; paint(b); return Promise.resolve({ status: 'ok', profile: cached, source: 'cache' }); }
    const id = b.id, request = ++b.request;
    b.pending = true; b.status = ''; paint(b);
    b.inFlight = send({ type: 'LOOKUP', url: b.url, manual: true }).then(result => {
      if (stopped || b.id !== id || b.request !== request || !b.link.isConnected || bindings.get(b.link) !== b)
        return { status: 'cancelled' };
      b.pending = false; b.inFlight = null;
      const item = result?.status === 'ok' && C.freshRecord(result.profile, id, Date.now());
      if (item) { cache.set(id, item); b.status = ''; }
      else {
        b.status = statusText[result?.status] ? result.status : 'unavailable';
      }
      for (const other of bindings.values()) if (other.id === id) paint(other);
      return item ? { status: 'ok', profile: item } : { status: b.status };
    });
    return b.inFlight;
  }

  function noteKey(card) {
    return card?.getAttribute('data-note-id') || card?.querySelector('a[href*="/explore/"], a[href*="/discovery/item/"]')?.getAttribute('href') || '';
  }
  function displayed(card) {
    for (let node = card; node; node = node.parentElement) {
      const style = getComputedStyle(node);
      if (node.hidden || node.getAttribute('aria-hidden') === 'true'
          || style.display === 'none' || style.visibility === 'hidden') return false;
    }
    return true;
  }
  function batchTargets() {
    // 以当前已加载的笔记列表顺序为准，不改排序，也不自动滚动补齐。
    const targets = [];
    let notes = 0;
    for (const card of document.querySelectorAll('.note-item')) {
      if (!displayed(card)) continue;
      if (++notes > 20) break;
      const link = [...card.querySelectorAll('a[href*="/user/profile/"]')]
        .find(a => bindings.has(a) && a.closest('.note-item') === card);
      const b = link && bindings.get(link);
      if (b) targets.push({ card, link, b, id: b.id, note: noteKey(card) });
    }
    return targets;
  }
  function sameBatchPage(run) {
    if (stopped || !enabled || location.href !== run.url) return false;
    const current = batchTargets();
    return current.length === run.targets.length && current.every((item, index) => {
      const old = run.targets[index];
      return item.card === old.card && item.link === old.link && item.id === old.id && item.note === old.note;
    });
  }
  function renderBatch() {
    if (stopped || !enabled || probe) { tools?.remove(); return; }
    if (!tools?.isConnected) {
      tools = document.createElement('div'); tools.id = 'mage-xhs-fans-tools'; tools.className = 'mage-xhs-fans-tools';
      tools.setAttribute('role', 'region'); tools.setAttribute('aria-label', '粉丝数查看');
      batchButton = document.createElement('button'); batchButton.type = 'button'; batchButton.id = 'mage-xhs-fans-batch';
      batchButton.title = '先完成关键词搜索和排序，再点击查看当前已加载列表前20条笔记的作者粉丝数。不会自动排序或向下加载。';
      batchButton.addEventListener('click', () => { void startBatch(); });
      batchStatus = document.createElement('p'); batchStatus.id = 'mage-xhs-fans-batch-status';
      batchStatus.setAttribute('role', 'status'); batchStatus.setAttribute('aria-live', 'polite');
      batchCancel = document.createElement('button'); batchCancel.type = 'button'; batchCancel.id = 'mage-xhs-fans-batch-cancel';
      batchCancel.textContent = '停止'; batchCancel.addEventListener('click', () => stopBatch('已停止'));
      tools.append(batchButton, batchStatus, batchCancel); (document.body || document.documentElement).append(tools);
    }
    batchButton.disabled = !!batchRun;
    batchButton.textContent = batchRun ? `正在查看 ${batchRun.completed}/${batchRun.targets.length}` : '查看当前前20条粉丝数';
    batchCancel.hidden = !batchRun; batchCancel.disabled = !!batchRun?.stopReason;
    batchStatus.textContent = batchRun
      ? batchRun.stopReason ? `${batchRun.stopReason}，当前查询结束后停止` : `已完成 ${batchRun.completed}/${batchRun.targets.length}条，按当前排序依次查看`
      : batchNote || '先排好序，再点按钮；其他笔记仍可逐条查看';
  }
  function stopBatch(reason) {
    if (!batchRun) return;
    if (!batchRun.stopReason) batchRun.stopReason = reason;
    renderBatch();
  }
  async function startBatch() {
    if (stopped || !enabled || probe || batchRun) return;
    scan();
    const targets = batchTargets();
    if (!targets.length) { batchNote = '页面没有可查询笔记，请先完成搜索并等待笔记加载'; renderBatch(); return; }
    const run = { targets, url: location.href, completed: 0, failed: 0, consecutiveFailures: 0,
      failedAuthors: new Map(), stopReason: '' };
    batchRun = run; renderBatch();
    const reasons = { login: '需要登录，已暂停',
      blocked: '需要完成验证，已暂停', 'rate-limited': '网站限制访问，已暂停', paused: '查询已暂停，请查看插件提示',
      disabled: '查看功能已关闭', cancelled: '查询已停止' };
    try {
      for (const target of targets) {
        if (run.stopReason) break;
        if (!sameBatchPage(run)) { run.stopReason = '页面排序或内容已变化，已停止'; break; }
        const previousFailure = !record(target.id) && !target.b.pending && run.failedAuthors.get(target.id);
        let result;
        if (previousFailure) {
          target.b.revealed = true; target.b.status = previousFailure.status;
          paint(target.b); result = previousFailure;
        } else {
          result = await lookup(target.b);
          if (result.status !== 'ok') run.failedAuthors.set(target.id, result);
        }
        run.completed++;
        if (result.status === 'ok') run.consecutiveFailures = 0;
        else { run.failed++; if (!previousFailure) run.consecutiveFailures++; }
        if (!sameBatchPage(run) && !run.stopReason) run.stopReason = '页面排序或内容已变化，已停止';
        if (!run.stopReason && reasons[result.status]) run.stopReason = reasons[result.status];
        if (!run.stopReason && run.consecutiveFailures >= 3) run.stopReason = '连续读取失败，已停止';
        renderBatch();
      }
    } catch { run.stopReason = '读取失败，已停止；可稍后逐条查看'; }
    finally {
      if (batchRun === run) {
        batchRun = null;
        batchNote = run.stopReason ? `${run.stopReason}（已处理 ${run.completed}/${targets.length}条）`
          : `已完成 ${run.completed}/${targets.length}条${run.failed ? `，其中 ${run.failed}条未读到` : '；其他笔记可逐条查看'}`;
        renderBatch();
      }
    }
  }

  function scan() {
    scheduled = false;
    if (stopped || !ready || !enabled || probe) return;
    renderBatch();
    const seen = new Set();
    for (const link of document.querySelectorAll('a[href*="/user/profile/"]')) {
      const p = C.profileUrl(link.getAttribute('href'));
      const name = link.textContent.trim();
      if (!p || !name || name.length > 80 || link.closest(`${OWN_UI}, nav, .side-bar`)) continue;
      const card = link.closest('.note-item'), note = noteKey(card);
      seen.add(link);
      let b = bindings.get(link);
      if (!b) {
        const badge = document.createElement('button');
        badge.type = 'button'; badge.className = 'mage-xhs-fans';
        b = { link, badge, card, note, id: p.id, url: p.url, name, pending: false, inFlight: null,
          revealed: false, request: 0, status: '' };
        bindings.set(link, b);
        badge.addEventListener('click', event => {
          event.preventDefault(); event.stopPropagation(); void lookup(b);
        });
        link.insertAdjacentElement('afterend', badge);
        paint(b);
      } else {
        if (b.id !== p.id || b.card !== card || b.note !== note) {
          b.id = p.id; b.card = card; b.note = note; b.pending = false; b.inFlight = null;
          b.revealed = false; b.request++; b.status = '';
        }
        b.url = p.url; b.name = name;
        if (!b.badge.isConnected || b.badge.previousElementSibling !== link) link.insertAdjacentElement('afterend', b.badge);
        paint(b);
      }
    }
    for (const [link, b] of bindings) if (!seen.has(link)) {
      b.badge.remove(); bindings.delete(link);
    }
    if (batchRun && !sameBatchPage(batchRun)) stopBatch('页面排序或内容已变化，已停止');
  }
  function schedule() {
    if (stopped || scheduled) return;
    scheduled = true; queueMicrotask(scan);
  }
  function applyState(state) {
    const wasPaused = pauseReason;
    enabled = state?.options?.enabled !== false;
    pauseReason = state?.pauseReason || '';
    cache.clear();
    for (const item of Array.isArray(state?.cache) ? state.cache : []) {
      const fresh = C.freshRecord(item, item?.id, Date.now());
      if (fresh) cache.set(fresh.id, fresh);
    }
    if (!enabled) {
      stopBatch('查看功能已关闭，已停止'); renderBatch();
      for (const b of bindings.values()) b.badge.remove();
      bindings.clear(); return;
    }
    for (const b of bindings.values()) {
      if (wasPaused && !pauseReason) b.status = '';
      paint(b);
    }
    schedule();
  }

  function observed(profile) {
    const p = C.profileUrl(location.href);
    if (!p || profile?.id !== p.id) return;
    const clean = C.cleanProfile(profile, p.id);
    if (!clean) return;
    const signature = `${p.id}:${clean.text}`;
    if (captured === signature) return;
    captured = signature; haveProfile = true;
    cache.set(p.id, { ...clean, at: Date.now() });
    void send({ type: 'OBSERVE', profile: clean });
    for (const b of bindings.values()) if (b.id === p.id) paint(b);
  }
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== C.ORIGIN || event.data?.channel !== CHANNEL) return;
    if (event.data.type === 'profile') observed(event.data.profile);
    if (probe && !haveProfile && event.data.type === 'issue'
        && ['login', 'blocked', 'rate-limited'].includes(event.data.status)) {
      failureSent = true; void send({ type: 'PROBE_FAILURE', status: event.data.status });
    }
  });
  function readDomProfile() {
    if (!domProfileAllowed) return;
    const p = C.profileUrl(location.href);
    if (!p || location.pathname !== firstPath) return;
    for (const box of document.querySelectorAll('.user-interactions, [class*="user-interactions"]')) {
      for (const row of box.children) {
        const label = row.querySelector('.name, .label');
        const count = row.querySelector('.count');
        if (label?.textContent.trim() !== '粉丝') continue;
        const value = C.normalizeCount(count?.textContent.trim());
        if (value) observed({ id: p.id, ...value });
      }
    }
  }
  function visible(element) {
    return !!element && getComputedStyle(element).display !== 'none' && element.getClientRects().length > 0;
  }
  function checkProbe(ticks) {
    readDomProfile();
    if (!probe || haveProfile || failureSent || ticks < 4) return;
    const body = (document.body?.textContent || '').slice(0, 3000);
    let status;
    if (/安全验证|访问受限|访问频繁|请完成验证/.test(document.title + ' ' + body)) status = 'blocked';
    else if ([...document.querySelectorAll('.login-container, .login-modal')].some(visible)
      || /登录后继续访问|请先登录|扫码登录/.test(body)) status = 'login';
    if (status) { failureSent = true; void send({ type: 'PROBE_FAILURE', status }); }
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.xhsFansState?.newValue) applyState(changes.xhsFansState.newValue);
  });
  chrome.runtime.onMessage.addListener(message => {
    if (message?.type === 'RESCAN') { for (const b of bindings.values()) b.status = ''; schedule(); }
  });
  window.addEventListener('mage-xhs-fans-navigation', () => {
    domProfileAllowed = false; stopBatch('页面已切换，已停止');
    batchNote = '页面已切换，排好序后可重新点击查看';
    for (const b of bindings.values()) {
      b.revealed = false; b.pending = false; b.inFlight = null; b.request++; b.status = ''; paint(b);
    }
    schedule();
  });
  window.addEventListener('pagehide', event => {
    stopBatch('页面已离开，已停止');
    if (event.persisted) return;
    stopped = true; domObserver?.disconnect();
    stopBatch('页面已关闭，已停止'); renderBatch();
    clearInterval(profileTimer); clearInterval(expiryTimer);
  });

  void (async () => {
    const state = await send({ type: 'INIT' });
    if (!state?.options) return;
    probe = state.probe === true; ready = true; applyState(state);
    window.postMessage({ channel: CHANNEL, type: 'ready' }, C.ORIGIN);
    let ticks = 0;
    checkProbe(ticks);
    if (C.profileUrl(location.href) && !haveProfile) {
      profileTimer = setInterval(() => {
        checkProbe(++ticks);
        if (haveProfile || failureSent || ticks >= 16) clearInterval(profileTimer);
      }, 750);
    }
    if (!probe) {
      domObserver = new MutationObserver(mutations => {
        if (mutations.some(m => {
          if (m.target.nodeType === 1 && m.target.closest?.(OWN_UI)) return false;
          const nodes = [...m.addedNodes, ...m.removedNodes];
          return m.type === 'attributes' || nodes.some(n => n.nodeType === 1 ? !n.matches(OWN_UI) : true);
        })) schedule();
      });
      domObserver.observe(document.documentElement, { childList: true, subtree: true, attributes: true,
        attributeFilter: ['href', 'data-note-id'] });
      expiryTimer = setInterval(() => { for (const b of bindings.values()) paint(b); }, 30000);
      scan();
    }
  })();
})();
