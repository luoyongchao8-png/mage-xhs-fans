(function (root) {
  'use strict';
  const C = typeof module === 'object' && module.exports ? require('./core.js') : root.XhsFans;
  class FanEngine {
    constructor({ read, initial = {}, now = () => Date.now(), sleep = ms => new Promise(r => setTimeout(r, ms)), save = async () => {} }) {
      this.read = read; this.now = now; this.sleep = sleep; this.save = save;
      // 兼容旧版存储字段，但升级后永久只允许点击查询。
      this.options = { enabled: initial.options?.enabled !== false, automatic: false };
      this.cache = new Map(); this.pending = new Map(); this.queue = [];
      this.running = false; this.lastStart = -Infinity; this.failures = 0;
      this.pauseReason = typeof initial.pauseReason === 'string' ? initial.pauseReason.slice(0, 30) : '';
      this.writes = Promise.resolve(); this.storageError = false;
      // 不再读取旧版 budget；升级后的持久化会移除插件小时额度。
      for (const item of Array.isArray(initial.cache) ? initial.cache.slice(-500) : []) {
        const record = C.freshRecord(item, item?.id, now());
        if (record) this.cache.set(record.id, record);
      }
    }
    snapshot() {
      return { options: { ...this.options }, cache: [...this.cache.values()],
        pauseReason: this.pauseReason };
    }
    persist() {
      const state = this.snapshot();
      this.writes = this.writes.then(() => this.save(state)).catch(() => { this.storageError = true; });
    }
    flush() { return this.writes; }
    observe(profile) {
      const clean = C.cleanProfile(profile, profile?.id);
      if (!clean) return null;
      const record = { ...clean, at: this.now() };
      this.cache.delete(record.id); this.cache.set(record.id, record);
      while (this.cache.size > 500) this.cache.delete(this.cache.keys().next().value);
      this.persist(); return record;
    }
    setOptions(options) {
      if (typeof options?.enabled === 'boolean') this.options.enabled = options.enabled;
      this.persist(); return { ...this.options };
    }
    clearCache() { this.cache.clear(); this.persist(); }
    resume() { this.pauseReason = ''; this.failures = 0; this.persist(); }
    summary() {
      const now = this.now();
      let fresh = 0;
      for (const [id, record] of this.cache) if (C.freshRecord(record, id, now)) fresh++;
      return { options: { ...this.options }, cached: fresh, hourlyLimit: null, queued: this.queue.length,
        running: this.running, pauseReason: this.pauseReason, storageError: this.storageError, now };
    }
    lookup(address, { manual = false } = {}) {
      const p = C.profileUrl(address);
      if (!p) return Promise.resolve({ status: 'invalid' });
      if (!this.options.enabled) return Promise.resolve({ status: 'disabled' });
      // 拒绝旧版内容脚本的自动请求，连缓存也只在点击后返回。
      if (manual !== true) return Promise.resolve({ status: 'manual' });
      const cached = C.freshRecord(this.cache.get(p.id), p.id, this.now());
      if (cached) return Promise.resolve({ status: 'ok', profile: cached, source: 'cache' });
      if (this.pauseReason) return Promise.resolve({ status: 'paused', reason: this.pauseReason });
      if (this.pending.has(p.id)) return this.pending.get(p.id);
      if (this.pending.size >= 16) return Promise.resolve({ status: 'queue-full' });
      let resolve;
      const promise = new Promise(r => { resolve = r; });
      this.pending.set(p.id, promise); this.queue.push({ ...p, resolve, manual });
      void this.drain(); return promise;
    }
    async drain() {
      if (this.running) return;
      this.running = true;
      try {
        while (this.queue.length) {
          const job = this.queue.shift();
          let result;
          const cached = C.freshRecord(this.cache.get(job.id), job.id, this.now());
          if (!this.options.enabled) result = { status: 'disabled' };
          else if (!job.manual) result = { status: 'manual' };
          else if (cached) result = { status: 'ok', profile: cached, source: 'cache' };
          else if (this.pauseReason) result = { status: 'paused', reason: this.pauseReason };
          else {
            const delay = 3000 - (this.now() - this.lastStart);
            if (delay > 0) await this.sleep(delay);
            // 开关可能在排队间隔中被关闭。
            if (!this.options.enabled) {
              result = { status: 'disabled' };
            } else {
              this.lastStart = this.now();
              try { result = await this.read(job.url, job.id); }
              catch { result = { status: 'unavailable' }; }
              const clean = result?.status === 'ok' && C.cleanProfile(result.profile, job.id);
              if (clean) {
                result = { status: 'ok', profile: this.observe(clean), source: 'profile' }; this.failures = 0;
              } else {
                const allowed = ['login', 'blocked', 'rate-limited', 'timeout', 'unavailable', 'cancelled'];
                result = { status: allowed.includes(result?.status) ? result.status : 'unavailable' };
                if (['login', 'blocked', 'rate-limited'].includes(result.status)) this.pauseReason = result.status;
                else if (result.status !== 'cancelled' && ++this.failures >= 3) this.pauseReason = 'repeated-failure';
                this.persist();
              }
            }
          }
          this.pending.delete(job.id); job.resolve(result);
        }
      } finally { this.running = false; }
    }
  }
  if (typeof module === 'object' && module.exports) module.exports = { FanEngine };
  else root.XhsFanEngine = FanEngine;
})(globalThis);
