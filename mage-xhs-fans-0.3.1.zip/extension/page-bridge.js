(() => {
  'use strict';
  if (location.origin !== 'https://www.xiaohongshu.com' || window !== window.top || window.__mageXhsFansBridge) return;
  Object.defineProperty(window, '__mageXhsFansBridge', { value: true, configurable: true });
  const C = globalThis.XhsFans, CHANNEL = 'mage-xhs-fans-v1';
  const firstPath = location.pathname, profiles = new Map();
  let lastInitial = '', pollTimer, initialAllowed = true, initialComplete = false, priorPath = firstPath;
  function routeChanged() {
    if (location.pathname !== priorPath) {
      priorPath = location.pathname;
      window.dispatchEvent(new Event('mage-xhs-fans-navigation'));
    }
    if (location.pathname !== firstPath) { initialAllowed = false; clearInterval(pollTimer); }
  }
  for (const method of ['pushState', 'replaceState']) {
    const original = history[method];
    history[method] = function (...args) {
      const result = Reflect.apply(original, this, args); routeChanged(); return result;
    };
  }
  window.addEventListener('popstate', routeChanged);
  function publish(profile) {
    if (!profile) return;
    profiles.set(profile.id, { profile, at: Date.now() });
    while (profiles.size > 500) profiles.delete(profiles.keys().next().value);
    window.postMessage({ channel: CHANNEL, type: 'profile', profile }, C.ORIGIN);
  }
  function inspectState() {
    // 初始状态只绑定文档首次打开的主页，避免 SPA 换页后旧数据被套到新账号。
    if (!initialAllowed || initialComplete || location.pathname !== firstPath) return;
    const p = C.profileUrl(location.href);
    if (!p) return;
    const profile = C.fromState(window.__INITIAL_STATE__, p.id);
    if (!profile) return;
    const signature = `${profile.id}:${profile.text}`;
    if (signature === lastInitial) return;
    lastInitial = signature; initialComplete = true; clearInterval(pollTimer); publish(profile);
  }
  function relevant(address) {
    try {
      const u = new URL(address, C.ORIGIN);
      return u.protocol === 'https:' && ['www.xiaohongshu.com', 'edith.xiaohongshu.com'].includes(u.hostname)
        && !u.port && u.pathname === '/api/sns/web/v1/user/otherinfo' && C.validId(u.searchParams.get('target_user_id'));
    } catch { return false; }
  }
  function consume(json, address) { publish(C.fromResponse(json, address)); }
  function issue(status) {
    if (status === 429 || status === 461 || status === 403)
      window.postMessage({ channel: CHANNEL, type: 'issue', status: status === 429 ? 'rate-limited' : 'blocked' }, C.ORIGIN);
  }
  const originalFetch = window.fetch;
  if (typeof originalFetch === 'function') window.fetch = function (...args) {
    const pending = Reflect.apply(originalFetch, this, args);
    const requested = typeof args[0] === 'string' ? args[0] : args[0]?.url;
    pending.then(response => {
      const address = response.url || requested;
      if (!relevant(address)) return;
      issue(response.status);
      if (response.ok) response.clone().json().then(json => consume(json, address)).catch(() => {});
    }).catch(() => {});
    return pending;
  };
  if (typeof XMLHttpRequest === 'function') {
    const originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function (...args) {
      this.addEventListener('loadend', () => {
        try {
          if (!relevant(this.responseURL)) return;
          issue(this.status);
          if (this.status < 200 || this.status >= 300) return;
          if (this.responseType === 'json') consume(this.response, this.responseURL);
          else if (!this.responseType || this.responseType === 'text') consume(JSON.parse(this.responseText), this.responseURL);
        } catch { /* 附加读取不能影响原请求。 */ }
      }, { once: true });
      return Reflect.apply(originalSend, this, args);
    };
  }
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== C.ORIGIN || event.data?.channel !== CHANNEL || event.data.type !== 'ready') return;
    inspectState();
    for (const { profile, at } of profiles.values()) if (Date.now() - at < C.TTL)
      window.postMessage({ channel: CHANNEL, type: 'profile', profile }, C.ORIGIN);
  });
  inspectState();
  let ticks = 0;
  if (!initialComplete) pollTimer = setInterval(() => { inspectState(); if (++ticks >= 20) clearInterval(pollTimer); }, 750);
  window.addEventListener('pagehide', () => clearInterval(pollTimer), { once: true });
})();
