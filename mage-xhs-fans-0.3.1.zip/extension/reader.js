(function (root) {
  'use strict';
  const C = typeof module === 'object' && module.exports ? require('./core.js') : root.XhsFans;
  class ProfileReader {
    constructor({ tabs, saveJobs = async () => {}, timeout = 15000 }) {
      this.tabs = tabs; this.saveJobs = saveJobs; this.timeout = timeout;
      this.jobs = new Map(); this.writes = Promise.resolve();
    }
    persist() {
      const jobs = [...this.jobs].map(([tabId, job]) => ({ tabId, userId: job.id, touched: job.touched === true }));
      this.writes = this.writes.then(() => this.saveJobs(jobs)).catch(() => {});
      return this.writes;
    }
    isProbe(tabId) { return this.jobs.has(tabId); }
    activated(tabId) {
      const job = this.jobs.get(tabId);
      if (job) { job.touched = true; void this.persist(); }
    }
    async recover(jobs) {
      for (const job of Array.isArray(jobs) ? jobs.slice(0, 16) : []) {
        if (!Number.isInteger(job?.tabId) || !C.validId(job?.userId) || job.touched === true) continue;
        try {
          const tab = await this.tabs.get(job.tabId);
          if (!tab.active && C.profileUrl(tab.url)?.id === job.userId) await this.tabs.remove(tab.id);
        } catch { /* 标签页已关闭。 */ }
      }
      await this.saveJobs([]);
    }
    async open(address, id) {
      const p = C.profileUrl(address);
      if (!p || p.id !== id || this.jobs.size) return { status: 'unavailable' };
      let tab;
      try { tab = await this.tabs.create({ url: p.url, active: false }); }
      catch { return { status: 'unavailable' }; }
      if (!Number.isInteger(tab?.id)) return { status: 'unavailable' };
      let resolve;
      const result = new Promise(r => { resolve = r; });
      const job = { id, resolve, finishing: false, touched: tab.active === true };
      this.jobs.set(tab.id, job);
      job.timer = setTimeout(() => { void this.finish(tab.id, { status: 'timeout' }); }, this.timeout);
      await this.persist();
      return result;
    }
    deliver(tabId, result) {
      const job = this.jobs.get(tabId);
      if (!job || job.finishing) return false;
      if (result?.status === 'ok') {
        const profile = C.cleanProfile(result.profile, job.id);
        if (!profile) return false;
        void this.finish(tabId, { status: 'ok', profile }); return true;
      }
      if (!['login', 'blocked', 'rate-limited', 'unavailable', 'cancelled'].includes(result?.status)) return false;
      void this.finish(tabId, { status: result.status }); return true;
    }
    async finish(tabId, result) {
      const job = this.jobs.get(tabId);
      if (!job || job.finishing) return;
      job.finishing = true; clearTimeout(job.timer);
      try {
        const tab = await this.tabs.get(tabId);
        // 用户已经切到前台或导航到别处时保留，绝不关闭普通标签页。
        if (!job.touched && !tab.active && C.profileUrl(tab.url)?.id === job.id) await this.tabs.remove(tabId);
      } catch { /* 页面可能已被用户关闭。 */ }
      this.jobs.delete(tabId); await this.persist(); job.resolve(result);
    }
    async cancelAll() {
      await Promise.all([...this.jobs.keys()].map(id => this.finish(id, { status: 'cancelled' })));
    }
    removed(tabId) { void this.finish(tabId, { status: 'cancelled' }); }
  }
  if (typeof module === 'object' && module.exports) module.exports = { ProfileReader };
  else root.XhsProfileReader = ProfileReader;
})(globalThis);
