const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
const A = '619e0b66000000001000e923', B = '64abc123000000000100abcd';
async function until(fn) {
  const deadline = Date.now() + 1500;
  while (!fn()) { if (Date.now() > deadline) throw Error('等待 DOM 条件超时'); await new Promise(r => setTimeout(r, 5)); }
}
function page(html, state = {}, intersecting = true, onLookup) {
  const dom = new JSDOM(html, { url: 'https://www.xiaohongshu.com/explore', runScripts: 'outside-only' });
  const w = dom.window, messages = [], changes = [], runtime = [], intervals = [];
  const setInterval = w.setInterval.bind(w);
  w.setInterval = (fn, delay) => { intervals.push({ fn, delay }); return setInterval(fn, delay); };
  const readyMessage = new Promise(resolve => w.addEventListener('message', event => {
    if (event.data?.type === 'ready') resolve();
  }));
  const initial = { options: { enabled: true, automatic: false }, cache: [], ...state };
  w.chrome = {
    runtime: { onMessage: { addListener: fn => runtime.push(fn) }, sendMessage: async msg => {
      messages.push(msg);
      if (msg.type === 'INIT') return { ...initial, probe: initial.probe === true };
      if (msg.type === 'LOOKUP') return onLookup ? onLookup(msg) : reply(msg);
      return {};
    } },
    storage: { onChanged: { addListener: fn => changes.push(fn) } }
  };
  w.IntersectionObserver = class {
    constructor(cb) { this.cb = cb; }
    observe(target) { this.cb([{ target, isIntersecting: intersecting }]); }
    unobserve() {} disconnect() {}
  };
  for (const name of ['core.js', 'content.js']) w.eval(fs.readFileSync(path.join(__dirname, '../extension', name), 'utf8'));
  return { dom, w, messages, changes, runtime, intervals, close: async () => {
    await readyMessage;
    w.dispatchEvent(new w.PageTransitionEvent('pagehide'));
    await new Promise(resolve => setImmediate(resolve));
    w.close();
  } };
}
const card = (id, name = '作者', note = id) => `<section class="note-item" data-note-id="${note}"><div class="author-wrapper"><a class="author" href="/user/profile/${id}"><span class="name">${name}</span></a></div></section>`;
const reply = msg => ({ status: 'ok', profile: { id: new URL(msg.url, 'https://www.xiaohongshu.com').pathname.split('/').pop(),
  value: 0, text: '0', approximate: false, at: Date.now() } });
const numberId = n => n.toString(16).padStart(24, '0');
const cards = count => Array.from({ length: count }, (_, i) => card(numberId(i + 1), `作者${i + 1}`)).join('');
const batchButton = w => w.document.getElementById('mage-xhs-fans-batch');
const batchStatus = w => w.document.getElementById('mage-xhs-fans-batch-status')?.textContent || '';

test('缓存粉丝数先隐藏，点击才展示；头像链接不重复、其他站点不注入', async () => {
  const { close, w, messages } = page(card(A) + `<a href="https://evil.test/user/profile/${A}">外站</a><a href="/user/profile/${A}"><img alt="头像"></a>`,
    { cache: [{ id: A, value: 12345, text: '12,345', approximate: false, at: Date.now() }] });
  try {
    await until(() => w.document.querySelector('.mage-xhs-fans'));
    assert.equal(w.document.querySelectorAll('.mage-xhs-fans').length, 1);
    const badge = w.document.querySelector('.mage-xhs-fans');
    assert.equal(badge.textContent, '点击查看粉丝数');
    badge.click();
    await until(() => badge.textContent === '粉丝 12,345');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 0);
  } finally { await close(); }
});

test('未知不显示 0，点击按需读取后才显示真实的 0', async () => {
  const { close, w, messages } = page(card(A));
  try {
    await until(() => w.document.querySelector('.mage-xhs-fans'));
    const badge = w.document.querySelector('.mage-xhs-fans');
    assert.equal(badge.textContent, '点击查看粉丝数');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 0);
    badge.click(); await until(() => badge.textContent === '粉丝 0');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
  } finally { await close(); }
});

test('滚动新增、虚拟列表换作者和重复扫描不串数字、不重复插入', async () => {
  const { close, w } = page(card(A), { cache: [{ id: A, value: 10, text: '10', approximate: false, at: Date.now() }] });
  try {
    await until(() => w.document.querySelector('.mage-xhs-fans'));
    w.document.querySelector('.mage-xhs-fans').click();
    await until(() => w.document.querySelector('.mage-xhs-fans')?.textContent === '粉丝 10');
    const link = w.document.querySelector('a');
    link.href = `/user/profile/${B}`;
    await until(() => w.document.querySelector('.mage-xhs-fans')?.textContent === '点击查看粉丝数');
    w.document.body.insertAdjacentHTML('beforeend', card(A, '另一个位置'));
    await until(() => w.document.querySelectorAll('.mage-xhs-fans').length === 2);
    w.document.body.append(w.document.createElement('div'));
    await until(() => w.document.querySelectorAll('.mage-xhs-fans').length === 2);
    assert.equal(w.document.querySelectorAll('.mage-xhs-fans').length, 2);
  } finally { await close(); }
});

test('旧自动设置、可见作者、滚动和新增卡片均不查询；关闭显示移除按钮', async () => {
  const { close, w, changes, messages } = page(card(A), { options: { enabled: true, automatic: true } });
  try {
    await until(() => w.document.querySelector('.mage-xhs-fans'));
    w.dispatchEvent(new w.Event('scroll'));
    w.document.body.insertAdjacentHTML('beforeend', card(B));
    await until(() => w.document.querySelectorAll('.mage-xhs-fans').length === 2);
    changes[0]({ xhsFansState: { newValue: { options: { enabled: true, automatic: true }, cache: [] } } }, 'local');
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 0);
    for (const badge of w.document.querySelectorAll('.mage-xhs-fans')) assert.equal(badge.textContent, '点击查看粉丝数');
    changes[0]({ xhsFansState: { newValue: { options: { enabled: false, automatic: false }, cache: [] } } }, 'local');
    await until(() => !w.document.querySelector('.mage-xhs-fans'));
  } finally { await close(); }
});

test('页面退出后，已排队的 DOM 扫描不能再查询或插入标签', async () => {
  const { close, w } = page(card(A));
  try {
    await until(() => w.document.querySelector('.mage-xhs-fans'));
    w.document.body.insertAdjacentHTML('beforeend', card(B));
    w.dispatchEvent(new w.PageTransitionEvent('pagehide'));
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(w.document.querySelectorAll('.mage-xhs-fans').length, 1);
  } finally { await close(); }
});

test('屏幕外作者不会自动打开主页，仍可点击按需查询', async () => {
  const { close, w, messages } = page(card(A), { options: { enabled: true, automatic: true } }, false);
  try {
    await until(() => w.document.querySelector('.mage-xhs-fans'));
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 0);
    w.document.querySelector('.mage-xhs-fans').click();
    await until(() => w.document.querySelector('.mage-xhs-fans').textContent === '粉丝 0');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
  } finally { await close(); }
});

test('点击一个作者后不展示其他卡片的数字，同作者再点复用缓存', async () => {
  const { close, w, messages } = page(card(A) + card(A, '同作者另一条') + card(B, '其他作者'));
  try {
    await until(() => w.document.querySelectorAll('.mage-xhs-fans').length === 3);
    const badges = w.document.querySelectorAll('.mage-xhs-fans');
    badges[0].click();
    await until(() => badges[0].textContent === '粉丝 0');
    assert.equal(badges[1].textContent, '点击查看粉丝数');
    assert.equal(badges[2].textContent, '点击查看粉丝数');
    badges[1].click();
    await until(() => badges[1].textContent === '粉丝 0');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
  } finally { await close(); }
});

test('缓存更新、恢复暂停和 RESCAN 都不能替用户点击或展示粉丝数', async () => {
  const { close, w, messages, changes, runtime } = page(card(A), { pauseReason: 'blocked' });
  try {
    await until(() => w.document.querySelector('.mage-xhs-fans'));
    changes[0]({ xhsFansState: { newValue: { options: { enabled: true, automatic: true }, pauseReason: '',
      cache: [{ id: A, value: 10, text: '10', approximate: false, at: Date.now() }] } } }, 'local');
    runtime[0]({ type: 'RESCAN' });
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(w.document.querySelector('.mage-xhs-fans').textContent, '点击查看粉丝数');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 0);
  } finally { await close(); }
});

test('粉丝缓存到期只恢复查看按钮，定时检查不能自动重新读取', async () => {
  const { close, w, messages, intervals } = page(card(A));
  try {
    await until(() => w.document.querySelector('.mage-xhs-fans'));
    const badge = w.document.querySelector('.mage-xhs-fans');
    badge.click(); await until(() => badge.textContent === '粉丝 0');
    const expiredTime = Date.now() + 1_800_001;
    w.Date.now = () => expiredTime;
    intervals.find(interval => interval.delay === 30000).fn();
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(badge.textContent, '点击查看粉丝数');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
  } finally { await close(); }
});

test('页面批量按钮默认不查询，点击后只查看当前排序的前20条，后面仍能单查', async () => {
  const { close, w, messages } = page(`<main>${cards(25)}</main>`);
  try {
    await until(() => batchButton(w));
    const main = w.document.querySelector('main');
    main.prepend(main.lastElementChild);
    w.dispatchEvent(new w.Event('scroll'));
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 0);
    batchButton(w).click();
    await until(() => !batchButton(w).disabled && /已完成/.test(batchStatus(w)));
    const lookups = messages.filter(m => m.type === 'LOOKUP');
    assert.equal(lookups.length, 20);
    assert.equal(lookups[0].url.endsWith(numberId(25)), true);
    assert.equal(lookups[19].url.endsWith(numberId(19)), true);
    assert.equal(lookups.every(m => m.manual === true), true);
    const badges = w.document.querySelectorAll('.note-item .mage-xhs-fans');
    for (let i = 0; i < 20; i++) assert.equal(badges[i].textContent, '粉丝 0');
    for (let i = 20; i < 25; i++) assert.equal(badges[i].textContent, '点击查看粉丝数');
    badges[20].click(); await until(() => badges[20].textContent === '粉丝 0');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 21);
  } finally { await close(); }
});

test('批量查询复用相同作者缓存，重复点页面按钮也不重新读取', async () => {
  const html = Array.from({ length: 21 }, (_, i) => card(A, '同一作者', `note-${i}`)).join('');
  const { close, w, messages } = page(html);
  try {
    await until(() => batchButton(w));
    batchButton(w).click(); await until(() => !batchButton(w).disabled && /已完成/.test(batchStatus(w)));
    const badges = w.document.querySelectorAll('.mage-xhs-fans');
    assert.equal([...badges].filter(b => b.textContent === '粉丝 0').length, 20);
    assert.equal(badges[20].textContent, '点击查看粉丝数');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
    batchButton(w).click(); await until(() => !batchButton(w).disabled);
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
  } finally { await close(); }
});

test('同一次前20条里相同作者读取失败也不重复请求，其余卡片保留手动重试', async () => {
  const html = Array.from({ length: 21 }, (_, i) => card(A, '同作者', `note-${i}`)).join('');
  const { close, w, messages } = page(html, {}, true, async () => ({ status: 'unavailable' }));
  try {
    await until(() => batchButton(w)); batchButton(w).click();
    await until(() => !batchButton(w).disabled);
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
    assert.equal(w.document.querySelectorAll('.mage-xhs-fans')[20].textContent, '点击查看粉丝数');
  } finally { await close(); }
});

test('批量只选已显示的笔记，忽略页面其他位置的作者链接', async () => {
  const { close, w, messages } = page(`<a href="/user/profile/${A}">页面其他作者</a><main>${cards(22)}</main>`);
  try {
    w.document.querySelector('.note-item').style.display = 'none';
    await until(() => batchButton(w));
    batchButton(w).click(); await until(() => !batchButton(w).disabled && /已完成/.test(batchStatus(w)));
    const lookups = messages.filter(m => m.type === 'LOOKUP');
    assert.equal(lookups.length, 20);
    assert.equal(lookups[0].url.endsWith(numberId(2)), true);
    assert.equal(lookups[19].url.endsWith(numberId(21)), true);
    assert.equal(w.document.querySelector('body > .mage-xhs-fans').textContent, '点击查看粉丝数');
  } finally { await close(); }
});

test('页面批量串行处理，重复点击和后来加载的卡片不会扩充当前任务', async () => {
  let release, active = 0, peak = 0;
  const { close, w, messages } = page(`<main>${cards(20)}</main>`, {}, true, async msg => {
    peak = Math.max(peak, ++active);
    if (!release) await new Promise(resolve => { release = resolve; });
    active--; return reply(msg);
  });
  try {
    await until(() => batchButton(w));
    batchButton(w).click(); batchButton(w).click();
    await until(() => typeof release === 'function');
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
    w.document.querySelector('main').insertAdjacentHTML('beforeend', card(numberId(21)));
    release();
    await until(() => !batchButton(w).disabled && /已完成/.test(batchStatus(w)));
    assert.equal(peak, 1);
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 20);
    assert.equal(w.document.querySelectorAll('.mage-xhs-fans')[20].textContent, '点击查看粉丝数');
  } finally { await close(); }
});

test('查询期间重新排序会停止剩余任务，不继续读取旧排名', async () => {
  let release;
  const { close, w, messages } = page(`<main>${cards(5)}</main>`, {}, true,
    msg => new Promise(resolve => { release = () => resolve(reply(msg)); }));
  try {
    await until(() => batchButton(w)); batchButton(w).click();
    await until(() => typeof release === 'function');
    const main = w.document.querySelector('main'); main.prepend(main.lastElementChild);
    release();
    await until(() => !batchButton(w).disabled);
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
    assert.match(batchStatus(w), /变化|排序/);
  } finally { if (release) release(); await close(); }
});

test('切换关键词会停止批量，旧结果不会在新页面自动展开', async () => {
  let release;
  const { close, w, messages } = page(cards(5), {}, true,
    msg => new Promise(resolve => { release = () => resolve(reply(msg)); }));
  try {
    await until(() => batchButton(w)); batchButton(w).click();
    await until(() => typeof release === 'function');
    w.history.pushState({}, '', '/search_result?keyword=another');
    w.dispatchEvent(new w.Event('mage-xhs-fans-navigation'));
    release();
    await until(() => !batchButton(w).disabled);
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
    assert.match(batchStatus(w), /切换|变化/);
    for (const b of w.document.querySelectorAll('.mage-xhs-fans')) assert.equal(b.textContent, '点击查看粉丝数');
  } finally { if (release) release(); await close(); }
});

test('用户点停止后不再读取后续作者', async () => {
  let release;
  const { close, w, messages } = page(cards(5), {}, true,
    msg => new Promise(resolve => { release = () => resolve(reply(msg)); }));
  try {
    await until(() => batchButton(w)); batchButton(w).click();
    await until(() => typeof release === 'function');
    w.document.getElementById('mage-xhs-fans-batch-cancel').click(); release();
    await until(() => !batchButton(w).disabled);
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
    assert.match(batchStatus(w), /已停止/);
  } finally { if (release) release(); await close(); }
});

test('离开并被浏览器暂存的页面也会停止，返回后不自动续查', async () => {
  let release;
  const { close, w, messages } = page(cards(5), {}, true, msg => release ? reply(msg)
    : new Promise(resolve => { release = () => resolve(reply(msg)); }));
  try {
    await until(() => batchButton(w)); batchButton(w).click();
    await until(() => typeof release === 'function');
    w.dispatchEvent(new w.PageTransitionEvent('pagehide', { persisted: true })); release();
    await until(() => !batchButton(w).disabled);
    assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
    assert.match(batchStatus(w), /停止/);
  } finally { if (release) release(); await close(); }
});

test('平台限制或验证时批量立即停止，后面的卡片保持手动按钮', async () => {
  for (const status of ['login', 'blocked', 'rate-limited', 'paused']) {
    const { close, w, messages } = page(cards(5), {}, true,
      async () => ({ status }));
    try {
      await until(() => batchButton(w)); batchButton(w).click();
      await until(() => !batchButton(w).disabled);
      assert.equal(messages.filter(m => m.type === 'LOOKUP').length, 1);
      assert.match(batchStatus(w), /暂停|验证|登录|限制/);
      for (const b of [...w.document.querySelectorAll('.mage-xhs-fans')].slice(1)) assert.equal(b.textContent, '点击查看粉丝数');
    } finally { await close(); }
  }
});

test('没有笔记时不请求；关闭插件或后台读取页不提供页面批量入口', async () => {
  const f = page('<p>等待搜索</p>');
  try {
    await until(() => batchButton(f.w)); batchButton(f.w).click();
    await until(() => /没有|未找到/.test(batchStatus(f.w)));
    assert.equal(f.messages.filter(m => m.type === 'LOOKUP').length, 0);
    f.changes[0]({ xhsFansState: { newValue: { options: { enabled: false }, cache: [] } } }, 'local');
    await until(() => !batchButton(f.w));
  } finally { await f.close(); }
  const probe = page(cards(5), { probe: true });
  try {
    await until(() => probe.messages.some(m => m.type === 'INIT'));
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(batchButton(probe.w), null);
    assert.equal(probe.messages.filter(m => m.type === 'LOOKUP').length, 0);
  } finally { await probe.close(); }
});
