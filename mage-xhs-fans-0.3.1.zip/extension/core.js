(function (root) {
  'use strict';
  const ORIGIN = 'https://www.xiaohongshu.com';
  const TTL = 30 * 60 * 1000;
  const validId = id => typeof id === 'string' && /^[a-f0-9]{24}$/i.test(id);

  function profileUrl(input) {
    if (typeof input !== 'string' || input.length > 4096) return null;
    try {
      const u = new URL(input, ORIGIN);
      const m = u.pathname.match(/^\/user\/profile\/([a-f0-9]{24})\/?$/i);
      if (u.origin !== ORIGIN || u.username || u.password || !m) return null;
      const out = new URL(`/user/profile/${m[1].toLowerCase()}`, ORIGIN);
      for (const key of ['xsec_token', 'xsec_source']) {
        const value = u.searchParams.get(key);
        if (value && value.length <= 2048) out.searchParams.set(key, value);
      }
      return { id: m[1].toLowerCase(), url: out.href };
    } catch { return null; }
  }

  function normalizeCount(input) {
    if (typeof input === 'number') {
      if (!Number.isSafeInteger(input) || input < 0) return null;
      return { value: input, text: input.toLocaleString('en-US'), approximate: false };
    }
    if (typeof input !== 'string' || input.length > 40) return null;
    const text = input.trim();
    if (!text) return null;
    const m = text.match(/^(\d+(?:,\d{3})*|\d+)(\.\d+)?\s*([万亿wWkKmM]?)(\+?)$/);
    if (!m || (m[2] && !m[3])) return null;
    if (text.includes(',') && !/^\d{1,3}(?:,\d{3})+(?:[万亿wWkKmM]?\+?)$/.test(text)) return null;
    const units = { '': 1, 万: 1e4, 亿: 1e8, w: 1e4, k: 1e3, m: 1e6 };
    const value = Math.round(Number((m[1] + (m[2] || '')).replaceAll(',', '')) * units[m[3].toLowerCase()]);
    if (!Number.isSafeInteger(value) || value < 0) return null;
    const approximate = !!m[3] || !!m[4];
    return { value, text: approximate ? text.replace(/\s/g, '') : value.toLocaleString('en-US'), approximate };
  }

  function unwrap(value) {
    for (let i = 0; i < 4 && value && typeof value === 'object'; i++) {
      if (Array.isArray(value.interactions) || Array.isArray(value.interacts)) break;
      const key = ['value', '_value', '_rawValue'].find(k => value[k] && typeof value[k] === 'object');
      if (!key) break;
      value = value[key];
    }
    return value;
  }

  function fromProfile(input, expectedId) {
    if (!validId(expectedId)) return null;
    const data = unwrap(input);
    if (!data || typeof data !== 'object') return null;
    const basic = data.basicInfo || data.basic_info || {};
    for (const id of [data.userId, data.user_id, basic.userId, basic.user_id]) {
      if (id !== undefined && (!validId(id) || id.toLowerCase() !== expectedId.toLowerCase())) return null;
    }
    const items = data.interactions || data.interacts;
    if (!Array.isArray(items)) return null;
    const fans = items.find(x => x && (x.type === 'fans' || (!x.type && x.name === '粉丝')));
    const count = normalizeCount(fans?.count);
    return count ? { id: expectedId.toLowerCase(), ...count } : null;
  }

  function fromState(state, expectedId) {
    return fromProfile(state?.user?.userPageData, expectedId);
  }

  function fromResponse(data, address) {
    try {
      const url = new URL(address, ORIGIN);
      if (url.protocol !== 'https:' || !['www.xiaohongshu.com', 'edith.xiaohongshu.com'].includes(url.hostname)
          || url.port || url.username || url.password || url.pathname !== '/api/sns/web/v1/user/otherinfo') return null;
      const id = url.searchParams.get('target_user_id');
      if (!validId(id) || data?.success === false || (data?.code !== undefined && data.code !== 0)) return null;
      return fromProfile(data?.data, id);
    } catch { return null; }
  }

  function cleanProfile(record, expectedId) {
    if (!record || !validId(record.id) || record.id !== expectedId) return null;
    const count = normalizeCount(record.text);
    if (!count || count.value !== record.value || count.approximate !== record.approximate) return null;
    return { id: record.id, ...count };
  }

  function freshRecord(record, expectedId, now = Date.now()) {
    const profile = cleanProfile(record, expectedId);
    if (!profile || !Number.isFinite(record.at) || record.at > now || now - record.at >= TTL) return null;
    return { ...profile, at: record.at };
  }

  const api = { ORIGIN, TTL, validId, profileUrl, normalizeCount, fromProfile, fromState, fromResponse, cleanProfile, freshRecord };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else Object.defineProperty(root, 'XhsFans', { value: Object.freeze(api), configurable: true });
})(globalThis);
