const test = require('node:test');
const assert = require('node:assert/strict');
const { FanEngine } = require('../extension/engine.js');
const A = '619e0b66000000001000e923', B = '64abc123000000000100abcd';
const url = id => `https://www.xiaohongshu.com/user/profile/${id}`;
const profile = (id, count = 42) => ({ id, value: count, text: String(count), approximate: false });
function setup(reader, initial = {}) {
  let time = 10_000_000;
  const saved = [];
  const engine = new FanEngine({ read: reader, initial, now: () => time,
    sleep: async ms => { time += ms; }, save: async x => saved.push(structuredClone(x)) });
  return { engine, saved, advance: ms => time += ms };
}

test('缓存包含 0 时不打开主页；过期记录重新查询', async () => {
  let reads = 0;
  const { engine, advance } = setup(async (_, id) => { reads++; return { status: 'ok', profile: profile(id) }; });
  engine.observe(profile(A, 0));
  assert.equal((await engine.lookup(url(A), { manual: true })).profile.value, 0);
  assert.equal(reads, 0);
  advance(1_800_001);
  assert.equal((await engine.lookup(url(A), { manual: true })).profile.value, 42);
  assert.equal(reads, 1);
});

test('同时请求同一作者只读取一次，返回同一真实结果', async () => {
  let finish, reads = 0;
  const { engine } = setup(async (_, id) => { reads++; return new Promise(resolve => { finish = () => resolve({ status: 'ok', profile: profile(id) }); }); });
  const one = engine.lookup(url(A), { manual: true });
  const two = engine.lookup(url(A), { manual: true });
  await new Promise(resolve => setImmediate(resolve));
  finish();
  assert.equal((await one).profile.value, 42);
  assert.equal((await two).profile.value, 42);
  assert.equal(reads, 1);
});

test('查询串行且有间隔，忽略与请求账号不符的返回值', async () => {
  let active = 0, peak = 0;
  const times = [];
  const { engine } = setup(async (_, id) => {
    peak = Math.max(peak, ++active); times.push(engine.summary().now);
    await new Promise(resolve => setImmediate(resolve)); active--;
    return { status: 'ok', profile: profile(id === B ? A : id) };
  });
  const [a, b] = await Promise.all([engine.lookup(url(A), { manual: true }), engine.lookup(url(B), { manual: true })]);
  assert.equal(a.status, 'ok'); assert.equal(b.status, 'unavailable');
  assert.equal(peak, 1); assert.ok(times[1] - times[0] >= 3000);
});

test('平台验证后暂停，下一账号不再打开主页', async () => {
  let reads = 0;
  const { engine } = setup(async () => { reads++; return { status: 'blocked' }; });
  assert.equal((await engine.lookup(url(A), { manual: true })).status, 'blocked');
  assert.equal((await engine.lookup(url(B), { manual: true })).status, 'paused');
  assert.equal(reads, 1);
  assert.equal(engine.summary().pauseReason, 'blocked');
});

test('已禁用和外站地址不会打开页面', async () => {
  let reads = 0;
  const { engine } = setup(async (_, id) => { reads++; return { status: 'ok', profile: profile(id) }; });
  assert.equal((await engine.lookup('https://evil.test/')).status, 'invalid');
  engine.setOptions({ enabled: false });
  assert.equal((await engine.lookup(url(B))).status, 'disabled');
  assert.equal(reads, 0);
});

test('缓存持久化不包含 URL 安全参数，重启后仍可使用缓存', async () => {
  const { engine, saved } = setup(async (_, id) => ({ status: 'ok', profile: profile(id) }));
  await engine.lookup(url(A) + '?xsec_token=sample-test-token', { manual: true });
  await engine.flush();
  const state = saved.at(-1);
  assert.equal(JSON.stringify(state).includes('sample-test-token'), false);
  assert.equal(Object.hasOwn(state, 'budget'), false);
  const restarted = setup(async () => { throw new Error('不应查询'); }, state).engine;
  assert.equal((await restarted.lookup(url(A), { manual: true })).profile.value, 42);
  assert.equal(restarted.summary().hourlyLimit, null);
});

test('旧版自动开关为 true 也不能产生自动读取或返回隐藏的缓存', async () => {
  let reads = 0;
  const { engine } = setup(async (_, id) => { reads++; return { status: 'ok', profile: profile(id) }; },
    { options: { enabled: true, automatic: true } });
  assert.equal((await engine.lookup(url(A))).status, 'manual');
  engine.observe(profile(A));
  assert.equal((await engine.lookup(url(A), { manual: false })).status, 'manual');
  engine.setOptions({ automatic: true });
  assert.equal((await engine.lookup(url(B))).status, 'manual');
  assert.equal(reads, 0);
  assert.equal(engine.summary().hourlyLimit, null);
});

test('旧版额度已用完也可立即查询新作者，重复点击仍命中缓存', async () => {
  let reads = 0;
  const { engine } = setup(async (_, id) => { reads++; return { status: 'ok', profile: profile(id) }; },
    { budget: { start: 10_000_000, used: 60 } });
  assert.equal((await engine.lookup(url(A), { manual: true })).status, 'ok');
  assert.equal((await engine.lookup(url(A), { manual: true })).profile.value, 42);
  assert.equal((await engine.lookup(url(B), { manual: true })).status, 'ok');
  assert.equal(reads, 2);
  await engine.flush();
  assert.equal(Object.hasOwn(engine.snapshot(), 'budget'), false);
  assert.equal(engine.summary().hourlyLimit, null);
});

test('同一小时超过60位不同作者仍成功读取，不产生插件额度拦截', async () => {
  let reads = 0;
  const { engine } = setup(async (_, id) => { reads++; return { status: 'ok', profile: profile(id) }; });
  const start = engine.summary().now;
  for (let i = 1; i <= 65; i++) {
    const id = i.toString(16).padStart(24, '0');
    assert.equal((await engine.lookup(url(id), { manual: true })).status, 'ok', `第${i}位作者`);
  }
  assert.equal(reads, 65);
  assert.ok(engine.summary().now - start < 3_600_000);
});

test('升级忽略旧额度时，网站访问限制仍然暂停后续读取', async () => {
  let reads = 0;
  const { engine } = setup(async () => { reads++; return { status: 'rate-limited' }; },
    { budget: { start: 10_000_000, used: 60 } });
  assert.equal((await engine.lookup(url(A), { manual: true })).status, 'rate-limited');
  assert.equal((await engine.lookup(url(B), { manual: true })).status, 'paused');
  assert.equal(reads, 1);
});
