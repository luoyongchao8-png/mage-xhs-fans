'use strict';
importScripts('core.js', 'engine.js', 'reader.js');
const C = globalThis.XhsFans;
const reader = new XhsProfileReader({ tabs: chrome.tabs,
  saveJobs: jobs => chrome.storage.session.set({ xhsFansProbeJobs: jobs }) });
let engine;
const ready = (async () => {
  const [local, session] = await Promise.all([
    chrome.storage.local.get('xhsFansState'), chrome.storage.session.get('xhsFansProbeJobs')
  ]);
  await reader.recover(session.xhsFansProbeJobs);
  engine = new XhsFanEngine({ initial: local.xhsFansState,
    read: (url, id) => reader.open(url, id),
    save: state => chrome.storage.local.set({ xhsFansState: state }) });
  // 将旧版 automatic=true 迁移为关闭、移除小时额度，保留缓存与网站暂停状态。
  engine.persist(); await engine.flush();
})();

function isPopup(sender) {
  return sender?.id === chrome.runtime.id && sender.url === chrome.runtime.getURL('popup.html');
}
function isContent(sender) {
  try {
    return sender?.id === chrome.runtime.id && Number.isInteger(sender.tab?.id) && sender.frameId === 0
      && new URL(sender.url).origin === C.ORIGIN;
  } catch { return false; }
}
async function handle(message, sender) {
  if (!message || typeof message.type !== 'string') return { status: 'invalid' };
  const popup = isPopup(sender), content = isContent(sender);
  if (!popup && !content) return { status: 'forbidden' };
  if (message.type === 'INIT' && content) return { ...engine.snapshot(), probe: reader.isProbe(sender.tab.id) };
  if (message.type === 'GET_STATE' && popup) return engine.summary();
  if (message.type === 'SET_OPTIONS' && popup) {
    engine.setOptions(message.options);
    if (!engine.options.enabled) await reader.cancelAll();
    await engine.flush(); return engine.summary();
  }
  if (message.type === 'CLEAR_CACHE' && popup) { engine.clearCache(); await engine.flush(); return engine.summary(); }
  if (message.type === 'RESUME' && popup) { engine.resume(); await engine.flush(); return engine.summary(); }
  if (message.type === 'LOOKUP' && content && !reader.isProbe(sender.tab.id))
    return engine.lookup(message.url, { manual: message.manual === true });
  if (message.type === 'OBSERVE' && content) {
    const address = C.profileUrl(sender.url);
    const profile = address && C.cleanProfile(message.profile, address.id);
    if (!profile) return { status: 'invalid' };
    if (reader.isProbe(sender.tab.id)) reader.deliver(sender.tab.id, { status: 'ok', profile });
    else engine.observe(profile);
    return { status: 'ok' };
  }
  if (message.type === 'PROBE_FAILURE' && content && reader.isProbe(sender.tab.id))
    return { status: reader.deliver(sender.tab.id, { status: message.status }) ? 'ok' : 'invalid' };
  return { status: 'forbidden' };
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  void ready.then(() => handle(message, sender)).then(respond).catch(() => respond({ status: 'unavailable' }));
  return true;
});
chrome.tabs.onRemoved.addListener(id => reader.removed(id));
chrome.tabs.onActivated.addListener(info => reader.activated(info.tabId));
