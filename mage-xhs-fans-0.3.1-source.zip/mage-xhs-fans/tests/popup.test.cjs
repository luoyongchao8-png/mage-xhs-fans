const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
async function until(fn) {
  const end = Date.now() + 1000;
  while (!fn()) { if (Date.now() > end) throw Error('设置未更新'); await new Promise(r => setTimeout(r, 5)); }
}
test('弹窗显示不设次数上限和暂停原因，显示开关及恢复可用', async () => {
  const root = path.join(__dirname, '../extension');
  const dom = new JSDOM(fs.readFileSync(path.join(root, 'popup.html'), 'utf8'), { runScripts: 'outside-only' });
  const w = dom.window, messages = [];
  const state = { options: { enabled: true, automatic: false }, used: 5, cached: 3, queued: 0, pauseReason: 'login',
    now: 10_000_000, resetAt: 13_600_000 };
  w.chrome = { runtime: { sendMessage: async msg => {
    messages.push(msg);
    if (msg.type === 'SET_OPTIONS') state.options = msg.options;
    if (msg.type === 'RESUME') state.pauseReason = '';
    return structuredClone(state);
  } } };
  try {
    w.eval(fs.readFileSync(path.join(root, 'popup.js'), 'utf8'));
    await until(() => !w.document.querySelector('#resume').hidden);
    assert.match(w.document.querySelector('#status').textContent, /登录/);
    assert.equal(w.document.querySelector('#automatic'), null);
    assert.match(w.document.querySelector('#numbers').textContent, /不设次数上限/);
    assert.doesNotMatch(w.document.querySelector('#numbers').textContent, /\/ 60|分钟后恢复/);
    const enabled = w.document.querySelector('#enabled'); enabled.checked = false;
    enabled.dispatchEvent(new w.Event('change'));
    await until(() => messages.some(m => m.type === 'SET_OPTIONS'));
    assert.deepEqual(JSON.parse(JSON.stringify(messages.find(m => m.type === 'SET_OPTIONS').options)), { enabled: false });
    await until(() => !w.document.querySelector('#resume').disabled);
    w.document.querySelector('#resume').click();
    await until(() => w.document.querySelector('#resume').hidden);
  } finally { w.close(); }
});
