"""生成小图标并按白名单打包；不读取浏览器资料或凭证。"""
from pathlib import Path
import hashlib
import json
import re
import struct
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = [
    'manifest.json', 'core.js', 'engine.js', 'reader.js', 'background.js',
    'page-bridge.js', 'content.js', 'content.css', 'popup.html', 'popup.js', 'popup.css',
    'icons/icon16.png', 'icons/icon32.png', 'icons/icon48.png', 'icons/icon128.png',
]


def png_chunk(kind, data):
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)


def make_icon(size):
    rows = []
    for y in range(size):
        row = bytearray([0])
        for x in range(size):
            u, v = (x + .5) / size, (y + .5) / size
            radius = .22
            cx, cy = min(max(u, radius), 1 - radius), min(max(v, radius), 1 - radius)
            inside = (u - cx) ** 2 + (v - cy) ** 2 <= radius ** 2
            color = (227, 62, 96, 255) if inside else (0, 0, 0, 0)
            if inside and any(a <= u <= b and top <= v <= .76 for a, b, top in
                              [(.20, .34, .53), (.43, .57, .37), (.66, .80, .22)]):
                color = (255, 255, 255, 255)
            row.extend(color)
        rows.append(row)
    data = b'\x89PNG\r\n\x1a\n'
    data += png_chunk(b'IHDR', struct.pack('>IIBBBBB', size, size, 8, 6, 0, 0, 0))
    data += png_chunk(b'IDAT', zlib.compress(b''.join(rows), 9)) + png_chunk(b'IEND', b'')
    return data


def validate():
    manifest = json.loads((ROOT / 'extension/manifest.json').read_text(encoding='utf-8'))
    package = json.loads((ROOT / 'package.json').read_text(encoding='utf-8'))
    if manifest['version'] != package['version']:
        raise ValueError('manifest 和 package 版本不一致')
    refs = [manifest['background']['service_worker'], manifest['action']['default_popup']]
    refs += list(manifest['icons'].values())
    for script in manifest['content_scripts']:
        refs += script.get('js', []) + script.get('css', [])
    for html in ['popup.html']:
        refs += re.findall(r'(?:src|href)="([^"#]+)"', (ROOT / 'extension' / html).read_text(encoding='utf-8'))
    for name in refs:
        if name not in RUNTIME or not (ROOT / 'extension' / name).is_file():
            raise ValueError(f'缺少或未登记的引用文件: {name}')
    if manifest['permissions'] != ['storage'] or manifest['host_permissions'] != ['https://www.xiaohongshu.com/*']:
        raise ValueError('权限超出设计范围')
    return manifest['version']


def build():
    icon_dir = ROOT / 'extension/icons'
    icon_dir.mkdir(exist_ok=True)
    for size in [16, 32, 48, 128]:
        (icon_dir / f'icon{size}.png').write_bytes(make_icon(size))
    version = validate()
    dist = ROOT / 'dist'
    dist.mkdir(exist_ok=True)
    output = dist / f'mage-xhs-fans-{version}.zip'
    names = [f'extension/{name}' for name in RUNTIME] + ['安装说明.md', '隐私说明.md', f'更新说明-{version}.md']
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name in names:
            source = ROOT / name
            if source.is_symlink() or not source.is_file():
                raise ValueError(f'打包文件缺失或为链接: {name}')
            item = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o100644 << 16
            archive.writestr(item, source.read_bytes())
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP 校验失败')
        for name in names:
            if archive.read(name) != (ROOT / name).read_bytes():
                raise ValueError(f'归档内容不匹配: {name}')
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    (dist / 'SHA256SUMS.txt').write_text(f'{digest}  {output.name}\n', encoding='utf-8')
    print(json.dumps({'file': str(output), 'version': version, 'bytes': output.stat().st_size,
                      'files': len(names), 'sha256': digest}, ensure_ascii=False))
    return output


if __name__ == '__main__':
    build()
