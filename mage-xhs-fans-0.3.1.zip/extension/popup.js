(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let busy = false;
  const reasons = { login: '请先登录小红书', blocked: '请先完成小红书页面验证',
    'rate-limited': '小红书暂时限制了访问，请稍后再试', 'repeated-failure': '连续读取失败，已暂停查询' };
  function render(state) {
    $('enabled').checked = state.options.enabled;
    $('enabled').disabled = busy;
    $('resume').hidden = !state.pauseReason;
    $('resume').disabled = busy;
    $('clear').disabled = busy;
    $('status').textContent = !state.options.enabled ? '查看按钮已关闭'
      : state.pauseReason ? reasons[state.pauseReason] || '查询已暂停'
      : state.running ? `正在读取作者主页${state.queued ? `，另有 ${state.queued} 位等待` : ''}`
      : '仅点击查询 · 不会自动读取';
    $('numbers').textContent = `有效缓存 ${Number(state.cached) || 0} 位 · 插件不设次数上限`;
    $('error').textContent = state.storageError ? '本地保存暂时失败，重开浏览器后可能需要重新查询。' : '';
  }
  async function request(message = { type: 'GET_STATE' }) {
    try {
      const state = await chrome.runtime.sendMessage(message);
      if (!state?.options) throw Error('unavailable');
      render(state); return state;
    } catch {
      $('error').textContent = '暂时无法连接插件后台，请在扩展管理页重新加载插件，再刷新小红书。';
      return null;
    }
  }
  async function change(message) {
    if (busy) return;
    busy = true;
    for (const id of ['enabled', 'resume', 'clear']) $(id).disabled = true;
    const state = await request(message);
    busy = false;
    if (state) render(state);
  }
  $('enabled').addEventListener('change', () => {
    void change({ type: 'SET_OPTIONS', options: { enabled: $('enabled').checked } });
  });
  $('resume').addEventListener('click', () => void change({ type: 'RESUME' }));
  $('clear').addEventListener('click', () => void change({ type: 'CLEAR_CACHE' }));
  void request();
  setInterval(() => { if (!busy) void request(); }, 1500);
})();
