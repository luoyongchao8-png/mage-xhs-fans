const test = require('node:test');
const assert = require('node:assert/strict');
const { ProfileReader } = require('../extension/reader.js');
const A = '619e0b66000000001000e923';
function fixture() {
  const tabs = new Map(), removed = [], jobsSaved = [];
  const api = {
    create: async ({ url }) => { const t = { id: 91, url, active: false }; tabs.set(t.id, t); return t; },
    get: async id => { if (!tabs.has(id)) throw Error('closed'); return tabs.get(id); },
    remove: async id => { removed.push(id); tabs.delete(id); }
  };
  const reader = new ProfileReader({ tabs: api, saveJobs: async x => jobsSaved.push(structuredClone(x)), timeout: 1000 });
  return { reader, tabs, removed, jobsSaved };
}
test('只接受对应查询标签页及相符的账号结果，并回收后台页', async () => {
  const { reader, removed } = fixture();
  const pending = reader.open(`https://www.xiaohongshu.com/user/profile/${A}`, A);
  await new Promise(r => setImmediate(r));
  const profile = { id: A, value: 0, text: '0', approximate: false };
  assert.equal(reader.isProbe(91), true);
  assert.equal(reader.deliver(92, { status: 'ok', profile }), false);
  assert.equal(reader.deliver(91, { status: 'ok', profile: { ...profile, id: '64abc123000000000100abcd' } }), false);
  assert.equal(reader.deliver(91, { status: 'ok', profile }), true);
  assert.equal((await pending).profile.value, 0);
  assert.deepEqual(removed, [91]);
});
test('用户激活查询页后不自动关闭', async () => {
  const { reader, tabs, removed } = fixture();
  const pending = reader.open(`https://www.xiaohongshu.com/user/profile/${A}`, A);
  await new Promise(r => setImmediate(r));
  tabs.get(91).active = true;
  reader.deliver(91, { status: 'login' });
  assert.equal((await pending).status, 'login');
  assert.deepEqual(removed, []);
});

test('用户曾激活后又离开的查询页，也会保留', async () => {
  const { reader, tabs, removed } = fixture();
  const pending = reader.open(`https://www.xiaohongshu.com/user/profile/${A}`, A);
  await new Promise(r => setImmediate(r));
  tabs.get(91).active = true; reader.activated(91);
  tabs.get(91).active = false;
  reader.deliver(91, { status: 'login' });
  assert.equal((await pending).status, 'login');
  assert.deepEqual(removed, []);
});
test('超时能结束读取并关闭插件后台页', async () => {
  const { reader, removed } = fixture();
  reader.timeout = 5;
  assert.equal((await reader.open(`https://www.xiaohongshu.com/user/profile/${A}`, A)).status, 'timeout');
  assert.deepEqual(removed, [91]);
});
test('重启恢复只清理登记且仍停留在相应主页的后台页', async () => {
  const { reader, tabs, removed } = fixture();
  tabs.set(1, { id: 1, active: false, url: `https://www.xiaohongshu.com/user/profile/${A}` });
  tabs.set(2, { id: 2, active: false, url: 'https://example.com' });
  tabs.set(3, { id: 3, active: true, url: `https://www.xiaohongshu.com/user/profile/${A}` });
  await reader.recover([{ tabId: 1, userId: A }, { tabId: 2, userId: A }, { tabId: 3, userId: A }]);
  assert.deepEqual(removed, [1]);
});
